// 미션 글 작성할 페이지

function MissionCreate() {
  return <div></div>;
}

export default MissionCreate;
