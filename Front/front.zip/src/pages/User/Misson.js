// 마이페이지에서 미션 버튼 누르면 이동할 페이지

function Mission() {
  return <div></div>;
}

export default Mission;
