// 분양게시판에서 강아지 하나하나 보여줄 컴포넌트

function DogListItem () {
    return (
        <div>강쥐들</div>
    )
}

export default DogListItem