import styled from "styled-components";

export const FooterWrapper = styled.div`
    &.footer {
        background-color: rgb(190, 190, 190);
        color: white;
        text-align: center;
    }
`